
var x = []; // Declare the array
var y = [];

var num = 60;

var v = [];

var z = [];
function setup() {

	createCanvas(400, 400);

	noStroke();

	fill(255, 200);

	for (var i = 0; i < 3000; i++) {

		//assign values to array based on for loop
		x[i] = random(-1000, 200); 

	}

}

function draw() {

	background(0);

	for (var i = 0; i < x.length; i++) {

		x[i] +=0.5;
      
		var y = i * 0.4;

		ellipse(x[i], y, 2, 2);}
    
	for (var t = num-1; t > 0; t--) {

		z[t] = z[t-1];

		v[t] = v[t-1];
	}

	z[0] = mouseX; 

	v[0] = mouseY; 
 {

		
fill(255, 0, 0);
		arc(z[t], v[t], 40, 40, 0, HALF_PI);
	}
}
